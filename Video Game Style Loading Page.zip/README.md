
  # Video Game Style Loading Page

  This is a code bundle for Video Game Style Loading Page. The original project is available at https://www.figma.com/design/hkLtm3UgBX9GbIhhhM2MIC/Video-Game-Style-Loading-Page.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  