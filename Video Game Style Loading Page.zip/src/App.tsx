import { useState } from "react";
import { LoadingScreen } from "./components/LoadingScreen";
import { MainMenu } from "./components/MainMenu";
import { AboutPage } from "./components/AboutPage";
import { RecruitersPage } from "./components/RecruitersPage";
import { ClipsPage } from "./components/ClipsPage";
import { ProjectsPage } from "./components/ProjectsPage";

type Page = "loading" | "menu" | "about" | "recruiters" | "clips" | "projects";

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>("loading");

  const handleLoadComplete = () => {
    setCurrentPage("menu");
  };

  const handleNavigate = (page: string) => {
    setCurrentPage(page as Page);
  };

  const handleBack = () => {
    setCurrentPage("menu");
  };

  return (
    <>
      {/* Scrolling "Work In Progress" bar */}
      {currentPage !== "loading" && (
        <div className="fixed top-0 left-0 right-0 z-50 bg-yellow-900/90 border-b border-yellow-600 overflow-hidden">
          <div className="animate-marquee whitespace-nowrap py-1 text-sm font-mono text-yellow-300">
            <span className="inline-block px-8">⚠ WORK IN PROGRESS ⚠</span>
            <span className="inline-block px-8">⚠ WORK IN PROGRESS ⚠</span>
            <span className="inline-block px-8">⚠ WORK IN PROGRESS ⚠</span>
            <span className="inline-block px-8">⚠ WORK IN PROGRESS ⚠</span>
            <span className="inline-block px-8">⚠ WORK IN PROGRESS ⚠</span>
            <span className="inline-block px-8">⚠ WORK IN PROGRESS ⚠</span>
            <span className="inline-block px-8">⚠ WORK IN PROGRESS ⚠</span>
            <span className="inline-block px-8">⚠ WORK IN PROGRESS ⚠</span>
          </div>
        </div>
      )}
      
      {currentPage === "loading" && (
        <LoadingScreen onLoadComplete={handleLoadComplete} />
      )}
      {currentPage === "menu" && (
        <MainMenu onNavigate={handleNavigate} />
      )}
      {currentPage === "about" && (
        <AboutPage onBack={handleBack} />
      )}
      {currentPage === "recruiters" && (
        <RecruitersPage onBack={handleBack} />
      )}
      {currentPage === "clips" && (
        <ClipsPage onBack={handleBack} />
      )}
      {currentPage === "projects" && (
        <ProjectsPage onBack={handleBack} />
      )}
    </>
  );
}